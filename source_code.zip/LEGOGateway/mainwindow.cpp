#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::finishVaris(void)
{
    // 正则表达式
    QRegExp r1("DF.+,(.+),.+,.+;$"); // 匹配变量名
    QRegExp r2("DF.+,.+,(.+),.+;$"); // 匹配公式
    QRegExp r3("DF.+,.+,.+,(.+)\\);$"); // 匹配单位
//    QRegExp r4(".*([a-zA-Z].+[0-9].*).*"); // 匹配变量

    // 遍历公式
    for(int i = 0; i < this->df.size(); i++) {
        QString gs = this->df[i];
        r1.indexIn(gs, 0);
        QString var = r1.cap(1);

    }
}

void MainWindow::calXvari(void)
{
    QString text = ui->textEdit->toPlainText();
    QStringList list = text.split("\n");
    bool ok;
    int val;
    for(int i = 0; i < list.size(); i++) {
        val = list.at(i).toInt(&ok, 2);
        this->mapX[QString("X").append(QString::number(i+1))] = val;
        ui->textEdit->append(QString("X").append(QString::number(i+1)).append(" = ").append(QString::number(val)));
    }
}

void MainWindow::on_pushButton_clicked()
{
    ui->textBrowser_2->clear();

    QScriptEngine scriptEngin;
    // 遍历公式，统计X变量和其它变量，去掉空格，换掉e
    scriptEngin.globalObject().setProperty("e", M_E);
//    QScriptValue val = scriptEngin.evaluate(ui->lineEdit->text());
//    ui->textBrowser->append(val.toString());
    // 替换X变量
    calXvari();
    QMap<QString, int>::Iterator iter;
    for(iter = mapX.begin(); iter != mapX.end(); iter++) {
        scriptEngin.globalObject().setProperty(iter.key(), iter.value());
    }

    // 正则表达式
    QRegExp r1("DF.+,(.+),.+,.+;$"); // 匹配变量名
    QRegExp r11("DF.+,(.+),\\(y=.+,.+;$"); // 匹配分段函数变量名
    QRegExp r2("DF.+,.+,(.+),.+;$"); // 匹配公式
    QRegExp r3("DF.+,.+,.+,(.+)\\);$"); // 匹配单位
    QRegExp r33("DF.+,.+,.+\\),(.+)\\);$"); // 匹配分段函数单位


    // 遍历公式
    for(int i = 0; i < this->df.size(); i++) {
        QString gs = this->df[i];
        QStringList gslist = gs.split(",");
        r1.indexIn(gs, 0);
        QString var = r1.cap(1); // 变量名
        var = gslist.at(1);
        r2.indexIn(gs, 0);
        QString gsstr = r2.cap(1); // 公式
//        ui->textBrowser_2->append(gsstr);
//        continue;
        r3.indexIn(gs, 0);
        QString unit = r3.cap(1); // 单位
        unit = QString(gslist.at(gslist.size() - 1)).remove(");");

        if(gs.contains(QRegExp(".+;.+;$"))) { // 计算(分段函数) (y=Z1*0.125,Z1<2^10;y=(Z1-2^11)*0.125,Z1>=2^10)
            gsstr.remove(QRegExp("^\\("));
            gsstr.remove(QRegExp("\\)$"));
            gsstr.remove(QRegExp("y=")); // Z1*0.125,Z1<2^10;(Z1-2^11)*0.125,Z1>=2^10
            gsstr.remove(QRegExp("Y="));
            QStringList list = gsstr.split(";"); // Z1*0.125,Z1<2^10 (Z1-2^11)*0.125,Z1>=2^10
            for(int j = 0; j < list.size(); j++) {
                QStringList list3 = list.at(j).split(","); // Z1*0.125 Z1<2^10
                QStringList list2;
                QString ss = "";
                for(int jj = 0; jj < list3.size()-1; jj++) ss.append(list3.at(jj));
                list2.push_back(ss);
                list2.push_back(list3.at(list3.size()-1));
                if(scriptEngin.evaluate(QString(list2.at(1)).replace(QRegExp("pow"), "Math.pow").replace(QRegExp("max"), "Math.max").replace(QRegExp("min"), "Math.min").replace(QRegExp("arctan"), "Math.atan")).toBool() == true) {
                    QScriptValue val = scriptEngin.evaluate(QString(list2.at(0)).replace(QRegExp("pow"), "Math.pow").replace(QRegExp("max"), "Math.max").replace(QRegExp("min"), "Math.min").replace(QRegExp("arctan"), "Math.atan"));
                    qsreal v = val.toNumber();
                    r11.indexIn(gs, 0);
//                    var = r11.cap(1); // 分段函数变量名
                    r33.indexIn(gs, 0);
//                    unit = r33.cap(1); // 分段函数单位
                    this->mapVal[var] = v;
                    this->mapBool[var] = true;
                    scriptEngin.globalObject().setProperty(var, v);

                    ui->textBrowser_2->append(var + " = " + val.toString() + " " + unit);
                    break;
                }
            }
        } else { // 计算(非分段函数)
            QScriptValue val = scriptEngin.evaluate(gsstr.replace(QRegExp("pow"), "Math.pow").replace(QRegExp("max"), "Math.max").replace(QRegExp("min"), "Math.min").replace(QRegExp("arctan"), "Math.atan"));
            qsreal v = val.toNumber();
            this->mapVal[var] = v;
            this->mapBool[var] = true;
            scriptEngin.globalObject().setProperty(var, v);

            ui->textBrowser_2->append(var + " = " + val.toString() + " " + unit);
        }
    }
}

void MainWindow::showUCDL(QString fileName)
{
    // 清空所有textBrowser
    ui->textBrowser->clear();
    ui->textBrowser_2->clear();
    ui->textEdit->clear();

    // 清空
    this->df.clear();
    int xcount = 0;
    QRegExp r(".*(X).*");

    QFile f(fileName);
    if(f.open(QIODevice::ReadOnly))
    {
        char buffer[1024];
        QString str;
        qint64 len;
        while((len = f.readLine(buffer, sizeof (buffer))) != -1)
        {
            str = buffer;
            str = str.trimmed();
            str.remove(QRegExp("\\s"));
            if(str.length() <= 0)
                continue;

            if(str.left(2) == "DF")
                this->df << str.left(qint32(len));

            if(str.left(2) == "DR") {
                int old = str.length();
                str = str.replace(QRegExp("X"), "");
                int new0 = str.length();
                xcount += old - new0;
            }
        }
    }
    f.close();

    ui->textBrowser->append(this->df.join("\n"));

    ui->textEdit->setPlaceholderText(QString("Please enter ").append(QString::number(xcount)).append(QString(" 8-bit binary strings\n(Separate each data with the enter key)")));
}

void MainWindow::calAllVari()
{

}

void MainWindow::on_pushButton_2_clicked()
{
    //定义文件对话框类
    QFileDialog *fileDialog = new QFileDialog(this);
    //定义文件对话框标题
    fileDialog->setWindowTitle(tr("load UCDL file"));
    //设置默认文件路径
    fileDialog->setDirectory("C:/");
    //设置文件过滤器
    fileDialog->setNameFilter(tr("Text files(*.txt)"));
    //设置可以选择多个文件,默认为只能选择一个文件QFileDialog::ExistingFiles
    //fileDialog->setFileMode(QFileDialog::ExistingFiles);
    //设置视图模式
    fileDialog->setViewMode(QFileDialog::Detail);
    //打印所有选择的文件的路径
    QStringList fileNames;
    qint8 flag = 0;
    if(fileDialog->exec())
    {
        fileNames = fileDialog->selectedFiles();
        flag = 1;
    }
    if(flag == 0)
        return;

    this->fileName = fileNames[0];

    fileDialog->close();

    this->showUCDL(this->fileName);
}

//void MainWindow::on_pushButton_3_clicked()
//{
//    QScriptEngine scriptEngin;
//    scriptEngin.globalObject().setProperty("e", M_E);
//    QScriptValue val = scriptEngin.evaluate(ui->lineEdit->text());
//    ui->textEdit->append(val.toString());
//}

void MainWindow::on_pushButton_4_clicked()
{
    msgBox.setWindowTitle("help");
    msgBox.setText("1: Click the \"open UCDL file\" button to select the script file, then the contents of the script file will be displayed in the first text box.\n\n2: Enter the data as required in the second text box.\n\n3: Finally click the \"calculate\" button to get the calculated result, and the result is displayed in the third text box.");
    msgBox.exec();
}
