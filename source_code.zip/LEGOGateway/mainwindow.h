#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QScriptEngine>
#include <QMap>
#include <QWidget>
#include <QFileDialog>
#include <QMessageBox>
#include <QFile>
#include <map>
#include <list>
#include <QRegExp>
#include <bits/stdc++.h>
#include <bitset>
#include <QTime>
#include <QList>
#include <QObject>
#include <math.h>
#include <QtMath>
#include "string.h"
#include <QDebug>
using namespace std;

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

//    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

private:
    Ui::MainWindow *ui;
    QMessageBox msgBox;

    QMap<QString, double> mapVal; // 变量<->值
    QMap<QString, bool> mapBool; // 变量<->是否已计算出值
    QMap<QString, int> mapX; // 终端上传变量<->值
    QList<QString> df; // 公式集合
    QString fileName; // UCDL file name

    void showUCDL(QString fileName);
    void calXvari(void);
    void finishVaris(void);
    void calAllVari(void);
};

#endif // MAINWINDOW_H
