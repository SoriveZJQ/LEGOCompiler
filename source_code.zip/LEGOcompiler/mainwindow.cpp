#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "string.h"
#include <QDebug>
#include <iostream>
#include <qthread.h>
#include <QApplication>
#include <QCoreApplication>
#include <QString>
#include <QtCore/qmath.h>
using namespace std;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    int k = 0;
    QString key;
    QFile f1(this->typeTableFileName);
    if(f1.open(QIODevice::ReadOnly))
    {
        char buffer[256];
        QString str;
        qint64 len;
        while((len = f1.readLine(buffer, sizeof (buffer))) != -1)
        {
            str = buffer;
            str = str.trimmed();
            str.remove(QRegExp("\\s"));
//            ui->textBrowser->append(str.left(qint32(len)));
            k++;
            if(k % 2 == 1)
                key = str.left(qint32(len));
            else
                this->typeTable[key] = str.left(qint32(len));
        }
    }
    f1.close();

    k = 0;
    QFile f2(this->functionTableFileName);
    if(f2.open(QIODevice::ReadOnly))
    {
        char buffer[256];
        QString str;
        qint64 len;
        while((len = f2.readLine(buffer, sizeof (buffer))) != -1)
        {
            str = buffer;
            str = str.trimmed();
            str.remove(QRegExp("\\s"));
//            ui->textBrowser->append(str.left(qint32(len)));
            k++;
            if(k % 2 == 1)
                key = str.left(qint32(len));
            else
                this->functionTable[key] = str.left(qint32(len));
        }
    }
    f2.close();

    k = 0;
    QFile f3(this->keywordTableFileName);
    if(f3.open(QIODevice::ReadOnly))
    {
        char buffer[256];
        QString str;
        qint64 len;
        while((len = f3.readLine(buffer, sizeof (buffer))) != -1)
        {
            str = buffer;
            str = str.trimmed();
            str.remove(QRegExp("\\s"));
            k++;
            if(k % 2 == 1)
                key = str.left(qint32(len));
            else
                this->keywordTable[key] = str.left(qint32(len));
        }
    }
    f3.close();

    k = 0;
    QFile f4(this->connectionTableFileName);
    if(f4.open(QIODevice::ReadOnly))
    {
        char buffer[256];
        QString str;
        qint64 len;
        while((len = f4.readLine(buffer, sizeof (buffer))) != -1)
        {
            str = buffer;
            str = str.trimmed();
            str.remove(QRegExp("\\s"));
//            ui->textBrowser->append(str.left(qint32(len)));
            k++;
            if(k % 2 == 1)
                key = str.left(qint32(len));
            else
                this->connectionTable[key] = str.left(qint32(len));
        }
    }
    f4.close();

}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_clicked()
{
    //定义文件对话框类
    QFileDialog *fileDialog = new QFileDialog(this);
    //定义文件对话框标题
    fileDialog->setWindowTitle(tr("load UCDL file"));
    //设置默认文件路径
    fileDialog->setDirectory("C:/");
    //设置文件过滤器
    fileDialog->setNameFilter(tr("Text files(*.txt)"));
    //设置可以选择多个文件,默认为只能选择一个文件QFileDialog::ExistingFiles
    //fileDialog->setFileMode(QFileDialog::ExistingFiles);
    //设置视图模式
    fileDialog->setViewMode(QFileDialog::Detail);
    //打印所有选择的文件的路径
    QStringList fileNames;
    qint8 flag = 0;
    if(fileDialog->exec())
    {
        fileNames = fileDialog->selectedFiles();
        flag = 1;
    }
    if(flag == 0)
        return;

    this->fileName = fileNames[0];

    fileDialog->close();
//    qDebug() << this->fileName;

    this->showUCDL(this->fileName);
}

void MainWindow::showUCDL(QString fileName)
{
    // 清空所有textBrowser
    ui->textBrowser_1->clear();
    ui->textBrowser_2->clear();
//    ui->textBrowser_3->clear();
    ui->textBrowser_4->clear();
    ui->textBrowser_5->clear();
//    ui->textBrowser_6->clear();

    // 清空
    this->pin.clear();
    this->df.clear();
    this->func.clear();
    this->protocolType = "";

    QFile f(fileName);
    if(f.open(QIODevice::ReadOnly))
    {
        char buffer[1024];
        QString str;
        qint64 len;
        int step = 0;
        while((len = f.readLine(buffer, sizeof (buffer))) != -1)
        {
            str = buffer;
            str = str.trimmed();
            str.remove(QRegExp("\\s"));
            if(str.length() <= 0)
                continue;

            if(str == "Function1(PinConfiguration){")
                step = 1;
            else if(str == "Function2(DataComputation){")
                step = 2;
            else if(str.left(9) == "Function3" || (str.left(9) == "Function2" && str != "Function2(DataComputation){"))
                step = 3;

            if(step == 1)
                this->pin << str.left(qint32(len)).replace(QRegExp("Pin"), "PIN");
            else if(step == 2)
                this->df << str.left(qint32(len));
            else if(step == 3)
                this->func << str.left(qint32(len));

            if(this->protocolType == "" && str.contains("PIN", Qt::CaseInsensitive)) {
                if(str.contains("SPI", Qt::CaseInsensitive)) this->protocolType = "SPI";
                else if(str.contains("I2C", Qt::CaseInsensitive)) this->protocolType = "I2C";
                else if(str.contains("I2S", Qt::CaseInsensitive)) this->protocolType = "I2S";
                else if(str.contains("SMBUS", Qt::CaseInsensitive)) this->protocolType = "SMBus";
                else if(str.contains("1-WIRE", Qt::CaseInsensitive)) this->protocolType = "1-Wire";
                else if(str.contains("UART", Qt::CaseInsensitive)) this->protocolType = "UART";
                else if(str.contains("SENT", Qt::CaseInsensitive)) this->protocolType = "SENT";
                else if(str.contains("PWM", Qt::CaseInsensitive)) this->protocolType = "PWM";
                else if(str.contains("PCM", Qt::CaseInsensitive)) this->protocolType = "PCM";
                else if(str.contains("RS485", Qt::CaseInsensitive)) this->protocolType = "RS485";
            }
        }
    }
    f.close();

    ui->textBrowser_1->append(this->pin.join("\n"));
//    ui->textBrowser_2->append(this->df.join("\n"));
    ui->textBrowser_2->append(this->func.join("\n"));

    qDebug() << this->protocolType;
}



int MainWindow::on_pushButton_2_clicked() // PIN
{
    if(this->pin.size() < 1) return 0;
    ui->textBrowser_4->clear();
    int bit_count = 0;

    // PIN(1,GND,0V,Open-Drain(type2));   PIN(2,ADC,5V); PIN(2,DAC,5V);
    QRegExp r1("PIN.+(\\d+),.*");
    QRegExp r2("PIN.+,(.+),.+,.+");
    QRegExp r22("PIN.+,(.+),.+"); // ADC/DAC
    QRegExp r3("PIN.+,.+,(.+),.+");
    QRegExp r33("PIN.+,.+,(.+)\\);"); // 5V
    QRegExp r4("PIN.+,.+,.+,(.+)\\);");
    QRegExp r5(".*([a-zA-Z]+).*");

    for(int i = 0; i < this->pin.size(); i++) {
        if(this->pin.at(i).left(3) != "PIN") {
            ui->textBrowser_4->append(this->pin.at(i));
            continue;
        }

        QString str = this->pin.at(i);
        QString data = "";
        data.append(this->keywordTable["PIN"]);
//        qDebug() << data;

        r1.indexIn(str, 0);
//        qDebug() << r1.captureCount();
        if(r1.cap(1) == "") {
            data = "lost PIN NUMBER";
            ui->textBrowser_4->append(data);
            continue;
        }
        int a = (r1.cap(1)).toInt();
//        qDebug() << a;
        bitset<6> b = a;
        data.append(QString::fromStdString(b.to_string()));

        // 特判I2S的SCK和UART的DW
        if(this->protocolType == "I2S" && str.contains("SCK", Qt::CaseInsensitive)) {
            QStringList qlist = str.split(",");
            data.append(this->typeTable["I2S"]);
            data.append(this->functionTable["SCK"]);
            if(QString(qlist.at(3)).contains("Standard", Qt::CaseInsensitive)) data.append("01");
            else if(QString(qlist.at(3)).contains("LeftJustified", Qt::CaseInsensitive)) data.append("10");
            else if(QString(qlist.at(3)).contains("RightJustified", Qt::CaseInsensitive)) data.append("11");
            QString strDataSize = QString(qlist.at(4));
            bool okk;
            int dataSize = strDataSize.left(strDataSize.length() - 4).toInt(&okk);
            bitset<8> b_dataSize = dataSize;
            data.append(QString::fromStdString(b_dataSize.to_string()));
            QString strFrameSize = QString(qlist.at(5));
            int frameSize = strFrameSize.left(strFrameSize.length() - 5).toInt(&okk);
            bitset<8> b_frameSize = frameSize;
            data.append(QString::fromStdString(b_frameSize.to_string()));
            QString strRateSize = QString(qlist.at(6));
            int rateSize = qRound(strRateSize.left(strRateSize.length() - 5).toFloat() / 999 * qPow(2, 10)); // 10bit表示数字
            bitset<10> b_rateSize = rateSize;
            data.append(QString::fromStdString(b_rateSize.to_string()));
            r5.indexIn(strRateSize, 0);
            if(r5.cap(1) == "Hz" || r5.cap(1) == "hz") data.append("01");
            else if(r5.cap(1) == "kHz" || r5.cap(1) == "Khz" || r5.cap(1) == "KHz" || r5.cap(1) == "khz") data.append("10");
            else if(r5.cap(1) == "mHz" || r5.cap(1) == "Mhz" || r5.cap(1) == "MHz" || r5.cap(1) == "mhz") data.append("11");

            ui->textBrowser_4->append(data);
            bit_count += data.length();
            continue;
        } else if(this->protocolType == "UART" && str.contains("DW", Qt::CaseInsensitive)) {
            QStringList qlist = str.split(",");
            data.append(this->typeTable["UART"]);
            data.append(this->functionTable["DW"]);
            bool ok;
            int baudRate = QString(qlist.at(3)).toInt(&ok);
            switch (baudRate) {
            case 2400:
                data.append("0001");
                break;
            case 4800:
                data.append("0010");
                break;
            case 9600:
                data.append("0011");
                break;
            case 19200:
                data.append("0100");
                break;
            case 38400:
                data.append("0101");
                break;
            case 57600:
                data.append("0110");
                break;
            case 115200:
                data.append("0111");
                break;
            case 128000:
                data.append("1000");
                break;
            case 230400:
                data.append("1001");
                break;
            case 256000:
                data.append("1010");
                break;
            case 460800:
                data.append("1011");
                break;
            default:
                break;
            }
            int dataSize = QString(qlist.at(4)).toInt(&ok);
            bitset<8> b_dataSize = dataSize;
            data.append(QString::fromStdString(b_dataSize.to_string()));
            int parityBit = QString(qlist.at(5)).toInt(&ok);
            bitset<8> b_parityBit = parityBit;
            data.append(QString::fromStdString(b_parityBit.to_string()));
            int stopBit = QString(qlist.at(6)).toInt(&ok);
            bitset<8> b_stopBit = stopBit;
            data.append(QString::fromStdString(b_stopBit.to_string()));
            int flowControl = QString(qlist.at(7)).toInt(&ok);
            bitset<8> b_flowControl = flowControl;
            data.append(QString::fromStdString(b_flowControl.to_string()));
            data.append(this->connectionTable["Open-Drain(type1)"]);

            ui->textBrowser_4->append(data);
            bit_count += data.length();
            continue;
        }

        // 特判PWM
        if(this->protocolType == "PWM" && str.contains("PWM", Qt::CaseInsensitive) && str.contains("DR")) {
            QStringList qlist = str.split(",");
            data.append(this->typeTable["PWM"]);
            data.append(this->functionTable["DR"]);
            QString strFre = QString(qlist.at(3));
            int fre = qRound(strFre.left(strFre.length() - 5).toFloat() / 999 * qPow(2, 10)); // 10bit表示数字
            bitset<10> b_fre = fre;
            data.append(QString::fromStdString(b_fre.to_string()));
            r5.indexIn(strFre, 0);
            if(r5.cap(1) == "Hz" || r5.cap(1) == "hz") data.append("01");
            else if(r5.cap(1) == "kHz" || r5.cap(1) == "Khz" || r5.cap(1) == "KHz" || r5.cap(1) == "khz") data.append("10");
            else if(r5.cap(1) == "mHz" || r5.cap(1) == "Mhz" || r5.cap(1) == "MHz" || r5.cap(1) == "mhz") data.append("11");


            ui->textBrowser_4->append(data);
            bit_count += data.length();
            continue;
        }

        // 特判PCM
        if(this->protocolType == "PCM" && str.contains("SCK", Qt::CaseInsensitive)) {
            QStringList qlist = str.split(",");
            data.append(this->typeTable["PCM"]);
            data.append(this->functionTable["SCK"]);
            QString strFre = QString(qlist.at(3));
            int fre = qRound(strFre.left(strFre.length() - 5).toFloat() / 999 * qPow(2, 10)); // 10bit表示数字
            bitset<10> b_fre = fre;
            data.append(QString::fromStdString(b_fre.to_string()));
            r5.indexIn(strFre, 0);
            if(r5.cap(1) == "Hz" || r5.cap(1) == "hz") data.append("01");
            else if(r5.cap(1) == "kHz" || r5.cap(1) == "Khz" || r5.cap(1) == "KHz" || r5.cap(1) == "khz") data.append("10");
            else if(r5.cap(1) == "mHz" || r5.cap(1) == "Mhz" || r5.cap(1) == "MHz" || r5.cap(1) == "mhz") data.append("11");

            ui->textBrowser_4->append(data);
            bit_count += data.length();
            continue;
        }
        if(this->protocolType == "PCM" && str.contains("CLK", Qt::CaseInsensitive)) {
            QStringList qlist = str.split(",");
            data.append(this->typeTable["PCM"]);
            data.append(this->functionTable["CLK"]);
            if(QString(qlist.at(3)).contains("Standard", Qt::CaseInsensitive)) data.append("01");
            else if(QString(qlist.at(3)).contains("LeftJustified", Qt::CaseInsensitive)) data.append("10");
            else if(QString(qlist.at(3)).contains("RightJustified", Qt::CaseInsensitive)) data.append("11");
            QString strDataSize = QString(qlist.at(4));
            bool okk;
            int dataSize = strDataSize.left(strDataSize.length() - 4).toInt(&okk);
            bitset<8> b_dataSize = dataSize;
            data.append(QString::fromStdString(b_dataSize.to_string()));
            QString strFrameSize = QString(qlist.at(5));
            int frameSize = strFrameSize.left(strFrameSize.length() - 5).toInt(&okk);
            bitset<8> b_frameSize = frameSize;
            data.append(QString::fromStdString(b_frameSize.to_string()));
            QString strRateSize = QString(qlist.at(6));
            int rateSize = qRound(strRateSize.left(strRateSize.length() - 5).toFloat() / 999 * qPow(2, 10)); // 10bit表示数字
            bitset<10> b_rateSize = rateSize;
            data.append(QString::fromStdString(b_rateSize.to_string()));
            r5.indexIn(strRateSize, 0);
            if(r5.cap(1) == "Hz" || r5.cap(1) == "hz") data.append("01");
            else if(r5.cap(1) == "kHz" || r5.cap(1) == "Khz" || r5.cap(1) == "KHz" || r5.cap(1) == "khz") data.append("10");
            else if(r5.cap(1) == "mHz" || r5.cap(1) == "Mhz" || r5.cap(1) == "MHz" || r5.cap(1) == "mhz") data.append("11");

            ui->textBrowser_4->append(data);
            bit_count += data.length();
            continue;
        }

        // 特判RS485的DR/DW
        if(this->protocolType == "RS485" && (str.contains("DR/DW") || str.contains("DW/DR"))) {
            QStringList qlist = str.split(",");
            data.append(this->typeTable["RS485"]);
            data.append(this->functionTable["DR/DW"]);
            if(QString(qlist.at(3)).left(2) == "D-") data.append("0");
            else if(QString(qlist.at(3)).left(2) == "D+") data.append("1");

            ui->textBrowser_4->append(data);
            bit_count += data.length();
            continue;
        }

        r2.indexIn(str, 0);
        r22.indexIn(str, 0);
//        qDebug() << r2.captureCount();
//        qDebug() << r2.cap(1);
        if(r2.cap(1) == "" && r22.cap(1) == "") {
            data = "lost TYPE";
            ui->textBrowser_4->append(data);
            continue;
        }
        data.append(this->typeTable[r2.cap(1)]);
        if(r2.cap(1) == "")
            data.append(this->typeTable[r22.cap(1)]);

        r3.indexIn(str, 0);
        r33.indexIn(str, 0);
        if(r3.cap(1) == "" && r33.cap(1) == "") {
            data = "lost FUNCTION";
            ui->textBrowser_4->append(data);
            continue;
        }
        if(r3.cap(1) != "") {
            if(r3.cap(1).right(1) == "V") {
                int v = qRound((r3.cap(1).left(r3.cap(1).length()-1)).toFloat() / 18 * 255);
    //            qDebug() << v;
                bitset<8> c = v;
                data.append(QString::fromStdString(c.to_string()));
            } else {
                QString funcstr = r3.cap(1);
                if(this->functionTable.find(funcstr) != this->functionTable.end())
                    data.append(this->functionTable[funcstr]);
                else {
                    QStringList list = funcstr.split("/");
                    for(int k = 0; k < list.size(); k++) {
                        data.append(this->functionTable[list.at(k)]);
                    }
                }
            }
        } else if(r33.cap(1) != "") {
            if(r33.cap(1).right(1) == "V") {
                int v = qRound((r33.cap(1).left(r33.cap(1).length()-1)).toFloat() / 18 * 255);
    //            qDebug() << v;
                bitset<8> c = v;
                data.append(QString::fromStdString(c.to_string()));
            } else {
                QString funcstr = r33.cap(1);
                if(this->functionTable.find(funcstr) != this->functionTable.end())
                    data.append(this->functionTable[funcstr]);
                else {
                    QStringList list = funcstr.split("/");
                    for(int k = 0; k < list.size(); k++) {
                        data.append(this->functionTable[list.at(k)]);
                    }
                }
            }
        }


        r4.indexIn(str, 0);
        if(r4.cap(1) == "" && r3.cap(1) == "" && r33.cap(1) == "") {
            data = "lost CONNECTION";
            ui->textBrowser_4->append(data);
            continue;
        }
        data.append(this->connectionTable[r4.cap(1)]);
        ui->textBrowser_4->append(data);
        bit_count += data.length();
    }

    return bit_count;
}

int MainWindow::on_pushButton_3_clicked() // meta operation
{
    if(this->func.size() < 1) return 0;
    ui->textBrowser_5->clear();
    int bit_count = 0;

    // CW(2, L),+2us; DR(3, 2, X1, X2),+200us; DR(1, ADC, X1, X2), +3ms; CW(2, DAC, 3V), +0us;
    QRegExp r1("(.+)\\(.+"); // CW  (yes)
    QRegExp r2(".+\\((\\d+),.+"); // 2  (yes)
    QRegExp r3(".+,(.+).*\\).+"); // L/H/12/0xab
    QRegExp r4(".+\\+(\\d+).+"); // 2  (yes)
    QRegExp r5(".+\\+\\d+([a-zA-Z]+);.*"); // ns-00,us-01,ms-10,s-11  (yes)

    for(int i = 0; i < this->func.size(); i++) {
        if(this->func.at(i).left(8) == "Function" || this->func.at(i).left(1) == "}") {
            ui->textBrowser_5->append(this->func.at(i));
            continue;
        }
        QString str = this->func.at(i);
        if(str.left(2) == "/*") {
            ui->textBrowser_5->append(str);
            continue;
        }

        QStringList list = str.split(",");

        QString data = "";
        r1.indexIn(str, 0);
        if(r1.cap(1) == "") {
            data = "lost KEYWORD";
            ui->textBrowser_5->append(data);
            continue;
        }
        data.append(this->keywordTable[r1.cap(1)]);
//        qDebug() << data;

        // 特判RS485的DW和DR
        // DW(RS485, n, 0xF1, ...), +1s;
        // DR(RS485, n, X1, ..., Xn), +1s;
        if(this->protocolType == "RS485" && r1.cap(1) == "DW") {
            int bytesNum = QString(list.at(1)).toInt();
            bitset<8> b_bytesNum = bytesNum;
            data.append(QString::fromStdString(b_bytesNum.to_string()));
            for(int ii = 2; ii < list.length()-1; ii++) {
                bool ok;
                int byteValue = QString(list.at(ii)).remove(QRegExp("\\)")).toInt(&ok, 16);
                bitset<8> b_byteValue = byteValue;
                data.append(QString::fromStdString(b_byteValue.to_string()));
            }

            r4.indexIn(str, 0); // 2
            if(r4.cap(1) == "") {
                data = "lost DELAY TIME";
                ui->textBrowser_5->append(data);
                continue;
            }
            int d4 = r4.cap(1).toInt();
            bitset<10> e = d4;
            data.append(QString::fromStdString(e.to_string()));

            r5.indexIn(str, 0);
            if(r5.cap(1) == "") {
                data = "lost DELAY UNIT";
                ui->textBrowser_5->append(data);
                continue;
            }
            QString d5 = r5.cap(1); // ns us ms s
            if(d5 == "ns") data.append("00");
            else if(d5 == "us") data.append("01");
            else if(d5 == "ms") data.append("10");
            else if(d5 == "s") data.append("11");
            else {
                data = "wrong DELAY UNIT";
                ui->textBrowser_5->append(data);
                continue;
            }

            ui->textBrowser_5->append(data);
            bit_count += data.length();
            continue;
        }
        if(this->protocolType == "RS485" && r1.cap(1) == "DR") {
            int varisNum = QString(list.at(1)).toInt();
            bitset<8> b_varisNum = varisNum;
            data.append(QString::fromStdString(b_varisNum.to_string()));

            r4.indexIn(str, 0); // 2
            if(r4.cap(1) == "") {
                data = "lost DELAY TIME";
                ui->textBrowser_5->append(data);
                continue;
            }
            int d4 = r4.cap(1).toInt();
            bitset<10> e = d4;
            data.append(QString::fromStdString(e.to_string()));

            r5.indexIn(str, 0);
            if(r5.cap(1) == "") {
                data = "lost DELAY UNIT";
                ui->textBrowser_5->append(data);
                continue;
            }
            QString d5 = r5.cap(1); // ns us ms s
            if(d5 == "ns") data.append("00");
            else if(d5 == "us") data.append("01");
            else if(d5 == "ms") data.append("10");
            else if(d5 == "s") data.append("11");
            else {
                data = "wrong DELAY UNIT";
                ui->textBrowser_5->append(data);
                continue;
            }

            ui->textBrowser_5->append(data);
            bit_count += data.length();
            continue;
        }

        r2.indexIn(str, 0);
        if(r2.cap(1) == "") {
            data = "lost PIN NUMBER";
            ui->textBrowser_5->append(data);
            continue;
        }
        int a = (r2.cap(1)).toInt();
        bitset<6> b = a;
        data.append(QString::fromStdString(b.to_string()));


        // 特判SPI的DW
        if(this->protocolType == "SPI" && r1.cap(1) == "DW" && list.length() >= 4) {
            bool ok;
            int bytesCount = QString(list.at(1)).toInt(&ok);
            bitset<8> b_bytesCount = bytesCount;
            data.append(QString::fromStdString(b_bytesCount.to_string()));
            for(int ii = 2; ii < list.length()-2; ii++) {
                int byteValue = QString(list.at(ii)).toInt(&ok, 16);
                bitset<8> b_byteValue = byteValue;
                data.append(QString::fromStdString(b_byteValue.to_string()));
            }
            int byteValue = QString(list.at(list.length()-2)).remove(QRegExp("\\)")).toInt(&ok, 16);
            bitset<8> b_byteValue = byteValue;
            data.append(QString::fromStdString(b_byteValue.to_string()));

            r4.indexIn(str, 0); // 2
            if(r4.cap(1) == "") {
                data = "lost DELAY TIME";
                ui->textBrowser_5->append(data);
                continue;
            }
            int d4 = r4.cap(1).toInt();
            bitset<10> e = d4;
            data.append(QString::fromStdString(e.to_string()));

            r5.indexIn(str, 0);
            if(r5.cap(1) == "") {
                data = "lost DELAY UNIT";
                ui->textBrowser_5->append(data);
                continue;
            }
            QString d5 = r5.cap(1); // ns us ms s
            if(d5 == "ns") data.append("00");
            else if(d5 == "us") data.append("01");
            else if(d5 == "ms") data.append("10");
            else if(d5 == "s") data.append("11");
            else {
                data = "wrong DELAY UNIT";
                ui->textBrowser_5->append(data);
                continue;
            }

            ui->textBrowser_5->append(data);
            bit_count += data.length();
            continue;
        }

        // 特判I2C的DR和DW
        if(this->protocolType == "I2C" && r1.cap(1) == "DR" && list.length() >= 6) {
            if(list.at(1) == "NOADDR") {
                data.append("00000000");
            } else {
                bool ok;
                int addr = QString(list.at(1)).toInt(&ok, 16);
                bitset<8> b_addr = addr;
                data.append(QString::fromStdString(b_addr.to_string()));
            }
            if(list.at(2) == "NOADDR") {
                data.append("00000000");
            } else {
                bool ok;
                int addr = QString(list.at(2)).toInt(&ok, 16);
                bitset<8> b_addr = addr;
                data.append(QString::fromStdString(b_addr.to_string()));
            }
            int varNum = QString(list.at(3)).toInt();
            bitset<8> b_varNum = varNum;
            data.append(QString::fromStdString(b_varNum.to_string()));

            r4.indexIn(str, 0); // 2
            if(r4.cap(1) == "") {
                data = "lost DELAY TIME";
                ui->textBrowser_5->append(data);
                continue;
            }
            int d4 = r4.cap(1).toInt();
            bitset<10> e = d4;
            data.append(QString::fromStdString(e.to_string()));

            r5.indexIn(str, 0);
            if(r5.cap(1) == "") {
                data = "lost DELAY UNIT";
                ui->textBrowser_5->append(data);
                continue;
            }
            QString d5 = r5.cap(1); // ns us ms s
            if(d5 == "ns") data.append("00");
            else if(d5 == "us") data.append("01");
            else if(d5 == "ms") data.append("10");
            else if(d5 == "s") data.append("11");
            else {
                data = "wrong DELAY UNIT";
                ui->textBrowser_5->append(data);
                continue;
            }

            ui->textBrowser_5->append(data);
            bit_count += data.length();
            continue;
        }
        if(this->protocolType == "I2C" && r1.cap(1) == "DW" && list.length() >= 4) {
            bool ok;
            int addr = QString(list.at(1)).toInt(&ok, 16);
            bitset<8> b_addr = addr;
            data.append(QString::fromStdString(b_addr.to_string()));
            addr = QString(list.at(2)).toInt(&ok, 16);
            b_addr = addr;
            data.append(QString::fromStdString(b_addr.to_string()));
            if(list.length() == 4) {
                // DW(2, 0xAE, 0x01), +1ms;
            } else {
                int bytesNum = QString(list.at(3)).remove(QRegExp("\\)")).toInt(&ok);
                bitset<8> b_bytesNum = bytesNum;
                data.append(QString::fromStdString(b_bytesNum.to_string()));
                if(bytesNum > 0) {
                    for(int ii = 4; ii < list.length()-1; ii++) {
                        int byteValue = QString(list.at(ii)).remove(QRegExp("\\)")).toInt(&ok, 16);
                        bitset<8> b_byteValue = byteValue;
                        data.append(QString::fromStdString(b_byteValue.to_string()));
                    }
                }
            }

            r4.indexIn(str, 0); // 2
            if(r4.cap(1) == "") {
                data = "lost DELAY TIME";
                ui->textBrowser_5->append(data);
                continue;
            }
            int d4 = r4.cap(1).toInt();
            bitset<10> e = d4;
            data.append(QString::fromStdString(e.to_string()));

            r5.indexIn(str, 0);
            if(r5.cap(1) == "") {
                data = "lost DELAY UNIT";
                ui->textBrowser_5->append(data);
                continue;
            }
            QString d5 = r5.cap(1); // ns us ms s
            if(d5 == "ns") data.append("00");
            else if(d5 == "us") data.append("01");
            else if(d5 == "ms") data.append("10");
            else if(d5 == "s") data.append("11");
            else {
                data = "wrong DELAY UNIT";
                ui->textBrowser_5->append(data);
                continue;
            }

            ui->textBrowser_5->append(data);
            bit_count += data.length();
            continue;
        }

        // 特判I2S的DR
        if(this->protocolType == "I2S" && r1.cap(1) == "DR" && str.contains("DIRECT", Qt::CaseInsensitive)) {
            // DR(2, I2S, DIRECT), +1s;
            resBox.setWindowTitle("I2S result");
            resBox.setText("The data uploaded from the terminal will be shown here.");
            resBox.exec();
            continue;
        }

        // 特判1-Wire的DW
        if(this->protocolType == "1-Wire" && r1.cap(1) == "DW" && list.length() >= 4) {
            bool ok;
            int bytesCount = QString(list.at(1)).toInt(&ok);
            bitset<8> b_bytesCount = bytesCount;
            data.append(QString::fromStdString(b_bytesCount.to_string()));
            for(int ii = 2; ii < list.length()-2; ii++) {
                int byteValue = QString(list.at(ii)).toInt(&ok, 16);
                bitset<8> b_byteValue = byteValue;
                data.append(QString::fromStdString(b_byteValue.to_string()));
            }
            int byteValue = QString(list.at(list.length()-2)).remove(QRegExp("\\)")).toInt(&ok, 16);
            bitset<8> b_byteValue = byteValue;
            data.append(QString::fromStdString(b_byteValue.to_string()));

            r4.indexIn(str, 0); // 2
            if(r4.cap(1) == "") {
                data = "lost DELAY TIME";
                ui->textBrowser_5->append(data);
                continue;
            }
            int d4 = r4.cap(1).toInt();
            bitset<10> e = d4;
            data.append(QString::fromStdString(e.to_string()));

            r5.indexIn(str, 0);
            if(r5.cap(1) == "") {
                data = "lost DELAY UNIT";
                ui->textBrowser_5->append(data);
                continue;
            }
            QString d5 = r5.cap(1); // ns us ms s
            if(d5 == "ns") data.append("00");
            else if(d5 == "us") data.append("01");
            else if(d5 == "ms") data.append("10");
            else if(d5 == "s") data.append("11");
            else {
                data = "wrong DELAY UNIT";
                ui->textBrowser_5->append(data);
                continue;
            }

            ui->textBrowser_5->append(data);
            bit_count += data.length();
            continue;
        }

        // 特判UART的DW和DR
        if(this->protocolType == "UART" && r1.cap(1) == "DW" && str.contains("UART", Qt::CaseInsensitive)) {
            QString dwType = QString(list.at(2)).remove(QRegExp("\\)"));
            if(dwType == "DIRECT") {
                // 网关编到DIRECT的时候，弹出一个框，选择ASCII或者HEX格式，手动填进去要发送的内容，编译器会替换成下面两句的格式
                bool ok = false;
                // 发送数据格式
                QStringList dataFormatList;
                dataFormatList << "a (string)" << "h (hexadecimal data)";
                QString selectedDF = "a";
                QString dataFormat = inputBox.getItem(this, "Select data format", "Select data format", dataFormatList, 0, false, &ok);
                if(ok && !dataFormat.isEmpty()) {
                    selectedDF = dataFormat;
                }
                qDebug() << selectedDF;

//                ok = false;
//                // 字符串长度或字节数
//                int num = 0;
//                int selectedNum = num;
//                if(selectedDF == "a") num = inputBox.getInt(this, "Input string length", "Input string length", 1, 1, 100, 1, &ok);
//                else if(selectedDF == "h") num = inputBox.getInt(this, "Input bytes number", "Input bytes number", 1, 1, 100, 1, &ok);
//                if(ok && num > 0) {
//                    selectedNum = num;
//                }
//                qDebug() << selectedNum;

                ok = false;
                // 字符串或各16进制字节
                int delay_num = 0;
                if(selectedDF.left(1) == "a") {
                    QString inputedStr = "";
                    QString inputStr = inputBox.getText(this, "Input string", "Input string", QLineEdit::Normal, "", &ok);
                    if(ok && !inputStr.isEmpty()) {
                        inputedStr = inputStr;
                    }
                    int strLen = inputedStr.length();
                    delay_num = strLen;

                    QByteArray array = QString("a").toUtf8();
                    bitset<8> b_array = int(array.at(0));
                    data.append(QString::fromStdString(b_array.to_string()));
                    bitset<8> b_strLen = strLen;
                    data.append(QString::fromStdString(b_strLen.to_string()));
                    QString t_str = QString(inputedStr).remove(QRegExp("\\)")).remove(QRegExp("\""));
                    array = t_str.toUtf8();
                    for(int ii = 0; ii < t_str.size(); ii++) {
                        b_array = int(array.at(ii));
                        data.append(QString::fromStdString(b_array.to_string()));
                    }
                } else if(selectedDF.left(1) == "h") {
                    QString inputedStr = "";
                    QString inputStr = inputBox.getText(this, "Input bytes", "Input bytes(Separate each hexadecimal byte with a space)", QLineEdit::Normal, "", &ok);
                    if(ok && !inputStr.isEmpty()) {
                        inputedStr = inputStr;
                    }
                    QStringList ilist = inputedStr.split(" ");
                    int bytesNum = ilist.length();
                    delay_num = bytesNum;

                    QByteArray array = QString("h").toUtf8();
                    bitset<8> b_array = int(array.at(0));
                    data.append(QString::fromStdString(b_array.to_string()));
                    bitset<8> b_bytesNum = bytesNum;
                    data.append(QString::fromStdString(b_bytesNum.to_string()));
                    for(int ii = 0; ii < ilist.length(); ii++) {
                        bool okk;
                        int byteValue = QString(ilist.at(ii)).remove(QRegExp("\\)")).toInt(&okk, 16);
                        bitset<8> b_byteValue = byteValue;
                        data.append(QString::fromStdString(b_byteValue.to_string()));
                    }
                }

                int d4 = delay_num;
                bitset<10> e = d4;
                data.append(QString::fromStdString(e.to_string()));

                QString d5 = "ms"; // ns us ms s
                if(d5 == "ns") data.append("00");
                else if(d5 == "us") data.append("01");
                else if(d5 == "ms") data.append("10");
                else if(d5 == "s") data.append("11");

                ui->textBrowser_5->append(data);
                bit_count += data.length();
                continue;

            } else if(dwType == "a") {
                QByteArray array = QString("a").toUtf8();
                bitset<8> b_array = int(array.at(0));
                data.append(QString::fromStdString(b_array.to_string()));
                int strLen = QString(list.at(3)).toInt();
                bitset<8> b_strLen = strLen;
                data.append(QString::fromStdString(b_strLen.to_string()));
                QString t_str = QString(list.at(4)).remove(QRegExp("\\)")).remove(QRegExp("\""));
                array = t_str.toUtf8();
                for(int ii = 0; ii < t_str.size(); ii++) {
                    b_array = int(array.at(ii));
                    data.append(QString::fromStdString(b_array.to_string()));
                }
            } else if(dwType == "h") {
                QByteArray array = QString("h").toUtf8();
                bitset<8> b_array = int(array.at(0));
                data.append(QString::fromStdString(b_array.to_string()));
                int bytesNum = QString(list.at(3)).toInt();
                bitset<8> b_bytesNum = bytesNum;
                data.append(QString::fromStdString(b_bytesNum.to_string()));
                for(int ii = 4; ii < list.length()-1; ii++) {
                    bool okk;
                    int byteValue = QString(list.at(ii)).remove(QRegExp("\\)")).toInt(&okk, 16);
                    bitset<8> b_byteValue = byteValue;
                    data.append(QString::fromStdString(b_byteValue.to_string()));
                }
            }

            r4.indexIn(str, 0); // 2
            if(r4.cap(1) == "") {
                data = "lost DELAY TIME";
                ui->textBrowser_5->append(data);
                continue;
            }
            int d4 = r4.cap(1).toInt();
            bitset<10> e = d4;
            data.append(QString::fromStdString(e.to_string()));

            r5.indexIn(str, 0);
            if(r5.cap(1) == "") {
                data = "lost DELAY UNIT";
                ui->textBrowser_5->append(data);
                continue;
            }
            QString d5 = r5.cap(1); // ns us ms s
            if(d5 == "ns") data.append("00");
            else if(d5 == "us") data.append("01");
            else if(d5 == "ms") data.append("10");
            else if(d5 == "s") data.append("11");
            else {
                data = "wrong DELAY UNIT";
                ui->textBrowser_5->append(data);
                continue;
            }

            ui->textBrowser_5->append(data);
            bit_count += data.length();
            continue;
        }
        if(this->protocolType == "UART" && r1.cap(1) == "DR" && str.contains("UART", Qt::CaseInsensitive)) {
            QString drType = QString(list.at(2)).remove(QRegExp("\\)"));
            if(drType == "DIRECT") {
                // 展示到弹窗中
                resBox.setWindowTitle("UART result");
                resBox.setText("The data uploaded from the terminal will be shown here.");
                resBox.exec();
                continue;
            } else {
                int varNum = QString(list.at(2)).toInt();
                bitset<8> b_varNum = varNum;
                data.append(QString::fromStdString(b_varNum.to_string()));
            }

            r4.indexIn(str, 0); // 2
            if(r4.cap(1) == "") {
                data = "lost DELAY TIME";
                ui->textBrowser_5->append(data);
                continue;
            }
            int d4 = r4.cap(1).toInt();
            bitset<10> e = d4;
            data.append(QString::fromStdString(e.to_string()));

            r5.indexIn(str, 0);
            if(r5.cap(1) == "") {
                data = "lost DELAY UNIT";
                ui->textBrowser_5->append(data);
                continue;
            }
            QString d5 = r5.cap(1); // ns us ms s
            if(d5 == "ns") data.append("00");
            else if(d5 == "us") data.append("01");
            else if(d5 == "ms") data.append("10");
            else if(d5 == "s") data.append("11");
            else {
                data = "wrong DELAY UNIT";
                ui->textBrowser_5->append(data);
                continue;
            }

            ui->textBrowser_5->append(data);
            bit_count += data.length();
            continue;
        }

        // 特判PCM的DR
        if(this->protocolType == "PCM" && r1.cap(1) == "DR" && str.contains("PCM") && str.contains("DIRECT")) {
            // DR(2, PCM, DIRECT), +1s;
            resBox.setWindowTitle("PCM result");
            resBox.setText("The data uploaded from the terminal will be shown here.");
            resBox.exec();
            continue;
        }

        QString d3 = QString(list.at(1)).remove(QRegExp("\\)")); // d3 = L/2/ADC/DAC
        r3.indexIn(str, 0);
        if(r3.cap(1) == "") {
            data = "lost PARAMETER";
            ui->textBrowser_5->append(data);
            continue;
        }
//        QString d3 = r3.cap(1); // L/H/12/0xab
        if(r1.cap(1) == "SR") {
            if(d3 == "L")
                data.append("0");
            else if(d3 == "H")
                data.append("1");
        } else if(r1.cap(1) == "CW") {
            if(d3 == "L")
                data.append("00000000").append("0");
            else if(d3 == "H")
                data.append("00000000").append("1");
            else if(d3 == "DAC") {
                data.append("00000001");
                QString dy = QString(list.at(2)).remove(QRegExp("\\)"));
                int vv = qRound((dy.left(dy.length()-1)).toFloat() / 5 * 255);
    //            qDebug() << v;
                bitset<8> cc = vv;
                data.append(QString::fromStdString(cc.to_string()));
            }
        } else if(r1.cap(1) == "DW") {
            d3 = d3.right(d3.length() - 2);
            bool ok;
            int val = d3.toInt(&ok, 16);
            bitset<8> bb = val;
//            d3 = d3.setNum(val, 2);
            d3 = QString::fromStdString(bb.to_string());
            data.append(d3);
        } else if(r1.cap(1) == "DR") {
            if(d3 == "ADC") {
                data.append("00000001");
            } else {
                a = d3.toInt();
                bitset<8> c = a;
                data.append("00000000").append(QString::fromStdString(c.to_string()));
            }
        }

        r4.indexIn(str, 0); // 2
        if(r4.cap(1) == "") {
            data = "lost DELAY TIME";
            ui->textBrowser_5->append(data);
            continue;
        }
        int d4 = r4.cap(1).toInt();
        bitset<10> e = d4;
        data.append(QString::fromStdString(e.to_string()));

        r5.indexIn(str, 0);
        if(r5.cap(1) == "") {
            data = "lost DELAY UNIT";
            ui->textBrowser_5->append(data);
            continue;
        }
        QString d5 = r5.cap(1); // ns us ms s
        if(d5 == "ns") data.append("00");
        else if(d5 == "us") data.append("01");
        else if(d5 == "ms") data.append("10");
        else if(d5 == "s") data.append("11");
        else {
            data = "wrong DELAY UNIT";
            ui->textBrowser_5->append(data);
            continue;
        }

        ui->textBrowser_5->append(data);
        bit_count += data.length();
    }

    return bit_count;
}

void MainWindow::on_pushButton_4_clicked()
{
    this->ui->label_3->clear();
    int bit_count1 = on_pushButton_2_clicked();
    int bit_count2 = on_pushButton_3_clicked();
    int bit_count_total = bit_count1 + bit_count2;
    if(bit_count_total > 0) this->ui->label_3->setText(QString("total bit count: ").append(QString::number(bit_count_total)));
}

void MainWindow::on_pushButton_5_clicked()
{
    msgBox.setWindowTitle("help");
    msgBox.setText("1: Click the \"load UCDL file\" button to select the script file to compile.\n\n2: Click the \"compile all\" button to compile everything at once, or click the \"compile\" button to compile each part separately.");
    msgBox.exec();
}
