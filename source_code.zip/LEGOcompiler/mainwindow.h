#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QWidget>
#include <QFileDialog>
#include <QMessageBox>
#include <QFile>
#include <map>
#include <list>
#include <QRegExp>
#include <bits/stdc++.h>
#include <bitset>
#include <QTime>
#include <QList>
#include <QObject>
#include <QInputDialog>
#include <QtMath>
using namespace std;

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private:
    Ui::MainWindow *ui;
//    QDialog *w = new QDialog;
//    QMessageBox w = new QMessageBox;
    QMessageBox msgBox;
    QMessageBox resBox;
    QInputDialog inputBox;


    QString fileName; // UCDL file name
    QString protocolType = ""; // communication protocol type

    map<QString, QString> typeTable;
    map<QString, QString> functionTable;
    map<QString, QString> keywordTable;
    map<QString, QString> connectionTable;

    QString typeTableFileName = "./tables/typeTable.txt";
    QString functionTableFileName = "./tables/functionTable.txt";
    QString keywordTableFileName = "./tables/keywordTable.txt";
    QString connectionTableFileName = "./tables/connectionTable.txt";

    QList<QString> pin;
    QList<QString> df;
    QList<QString> func;


    void showUCDL(QString fileName);

private slots:
    void on_pushButton_clicked();
    int on_pushButton_2_clicked();
    int on_pushButton_3_clicked();
    void on_pushButton_4_clicked();
    void on_pushButton_5_clicked();
};

#endif // MAINWINDOW_H
